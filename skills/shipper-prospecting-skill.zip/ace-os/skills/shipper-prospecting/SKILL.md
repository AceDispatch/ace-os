---
name: shipper-prospecting
description: Build a WIDE, UNVERIFIED candidate roster of potential flatbed-freight shippers in a target territory for Ace Dispatch's direct-shipper registry. Use whenever the task is to hunt, prospect, find, or build a list of candidate shippers (steel service centers, rebar fabricators, pipe/tube distributors, lumber/building-material wholesalers, precast/concrete makers, metal-building and machinery manufacturers, and similar heavy-freight shippers) in a geographic area. This is the FIRST stage of a two-stage funnel: this skill GENERATES and TAGS candidates only; a separate Investigator stage verifies onboarding doors. This skill is territory-agnostic and plug-and-play — give it any radius/area and it runs the same method. It does NOT verify carrier onboarding, portals, insurance, or freight volume — that is forbidden here and belongs to the Investigator. Trigger on "prospect shippers", "build a shipper list", "hunt shippers in [area]", "candidate roster".
---

# Shipper Prospecting — Ace Dispatch (Breadth Stage)

This skill runs the **Prospector**: stage one of the shipper-registry funnel. Its only
job is to produce a **wide, tagged roster of candidate shippers** in a target territory,
and to do it with disciplined honesty about where each candidate came from. A separate
**Investigator** stage takes this roster and verifies which candidates have a real,
carrier-accessible onboarding door. Keeping these two jobs separate is the whole design:
the Prospector is rewarded for *breadth*, the Investigator for *rigor*, and neither may
do the other's job.

## Governing philosophy — honest breadth, not false productivity

Carrier-direct shippers are valuable in inverse proportion to how easy they are to find.
The big anchors (Nucor, Gerdau, CMC) are findable by anyone and therefore low-edge; the
value is in the smaller, less-indexed shippers that ordinary search buries. So this skill
casts a **wide net** — noise is acceptable and expected at this stage, because the
Investigator kills false positives downstream cheaply.

The enemy of this stage is **the gravity toward looking productive**: backfilling an empty
hunting layer with easy finds, soft-pedaling sources that are hard to access, padding the
count with implausible names, claiming coverage that wasn't achieved. Every one of these
corrupts the provenance data the Investigator relies on to learn which hunting methods
actually work. **The honesty IS the product.** A truthful thin roster beats a padded fat one.

## The four discipline laws (non-negotiable)

These exist because a hand-run of this process violated all four. They are the reason this
skill exists; the layer taxonomy below is just the scaffold they hang on.

1. **Provenance honesty.** Every candidate is tagged with the layer and the specific source
   that *actually surfaced it*. A candidate found by ordinary web search is NOT relabeled
   into a more impressive-sounding layer. The tag records how the name was really found,
   because the Investigator's verdicts flow back against these tags to rank the hunting
   methods — a contaminated tag poisons that feedback loop.

2. **Empty layers report empty.** If a layer produces no genuine candidates, it reports
   zero. It is never backfilled with names discovered by other means to make it look
   productive. "This layer yielded nothing here" is a valid, valuable result.

3. **Low-confidence is flagged in-line.** Radius-edge candidates, likely-misfit commodities,
   and uncertain finds are flagged ON the candidate row — not buried in a caveats section
   at the end. The roster must let the Investigator see confidence at a glance.

4. **Access walls are primary targets, not footnotes.** When a high-value directory is
   gated (login, membership, paywall), that is a SIGNAL, not an obstacle: the wall is
   *why* the names behind it are non-obvious and valuable. Gated directories are recorded
   as priority targets to penetrate, never dismissed as "couldn't access."

## The in-universe plausibility screen (the ONLY filtering allowed here)

The Prospector may trim a candidate ONLY when the candidate's **already-captured data**
puts it out of universe. The bright-line test:

> **Does the judgment require NEW information about the company (a lookup, a site visit,
> a verification)? If yes, it is the Investigator's job — do not do it here.
> Can it be derived from the data the candidate already arrived with? If yes, it is a
> free limiter — apply it.**

Allowed limiters (no lookup required):
- **Radius.** The candidate's address is already captured — drop if clearly outside the
  target radius. (Flag, don't silently drop, anything near the edge — law 3.)
- **Commodity family.** The vein the candidate came from already declares its family — a
  precast roster yields precast, a hardwood directory yields lumber. Drop candidates from
  veins that plainly do not ship flatbed freight at all (e.g. a pure food-service or
  palletized-goods directory). This is reading the *source*, not researching the *company*.

FORBIDDEN here (all belong to the Investigator):
- Whether an onboarding door exists, or what kind.
- Whether there's a carrier portal, packet, or captive logistics entity.
- Insurance minimums, authority, safety scores.
- Freight volume or freight quality.
- Anything requiring opening the company's website or any record about it.

The door question — the entire point of the registry — is NEVER pre-judged here. The
roster stays wide on exactly the dimension we are hunting for.

## The hunting layers

Run the layers that fit the territory. Report candidates **grouped by the layer that found
them.** For each candidate capture the handoff record (see below).

- **Layer 1 — Anchors.** The big, obvious industrial shippers and their facilities in the
  area. Low effort, low novelty, necessary seed. **Cap this layer** — list them and move
  on. Do not let anchors dominate the roster; the value is downstream in Layers 2–3.

- **Layer 2 — Trade-registry sweep.** Directories and trade-association membership rolls
  where smaller shippers must appear regardless of weak SEO. **Richest layer for small,
  non-obvious shippers.** See `references/SOURCE_PLAYBOOK.md` for named productive veins
  and gated targets.

- **Layer 3 — Supplier-ring inference.** The customers and suppliers of the Layer 1 anchors
  who are themselves shippers — service centers that buy mill steel and re-ship, downstream
  fabricators, metal-building makers. Hunt by relationship. Productive mid-tier novelty.

- **Layer 4 — Freight-footprint reversal.** Detect shippers by the shadow their freight
  casts (carrier-forum loading threads, freight mentions). **VERIFICATION TOOL, NOT A
  DISCOVERY TOOL** — see doctrine. Highest value-per-hit, lowest hit-rate. Used to confirm
  freight activity at an *already-known* candidate name, NOT to discover unknown names by
  cold-trawling forums.

- **Layer 5 — RETIRED.** A geospatial/satellite read of industrial districts was tested
  and retired. The genuine satellite read (spotting rail spurs, trailer yards, laydown
  areas from overhead) is a human visual task, not an agent browsing task, and the
  textual-proxy version (rail-park tenant lists, chamber pages) collapsed into a
  duplicate of the Layer 2 directory sweep with no added value. Do NOT reinvent Layer 5.
  If overhead reading is ever wanted, it is a human-in-the-loop step outside this skill.

## The handoff contract (candidate record → Investigator)

The candidate record IS the interface between the Prospector and the Investigator — the
standard thread that lets the two stages stay cleanly swappable. Each candidate carries:

- **name** — company name
- **city / location** — as captured
- **commodity_family** — steel/metals, pipe/tube, rebar/fabrication, lumber/building
  materials, precast/concrete/aggregates, machinery/equipment, other industrial
- **layer** — which layer surfaced it (1–4)
- **source_tactic** — the specific directory / association / relationship / forum thread
- **source_url** — where found, wherever possible
- **confidence_flag** — in-line note for radius-edge, likely-misfit, or unverified-location
  candidates (law 3); blank if clean

The Prospector writes NO door/onboarding/freight fields. Those columns are the
Investigator's to fill. Output the roster grouped by layer, plus a **methods analysis**:
per-layer productivity, which specific veins were richest, which were dead ends, and any
gated directories to penetrate. The methods analysis is as valuable as the roster — it is
how the hunt itself gets smarter over time.

## How to run it
1. Take the territory (radius/area) and load `references/SOURCE_PLAYBOOK.md` and
   `references/SEARCH_DOCTRINE.md`.
2. Run Layers 1–4 per doctrine, applying the yield-based stop rules.
3. Apply only the in-universe plausibility screen. Tag every candidate truthfully.
4. Emit the grouped roster + methods analysis. Verify nothing.

Reference `references/SOURCE_PLAYBOOK.md` for ranked sources and `references/SEARCH_DOCTRINE.md`
for query patterns and stop rules.
